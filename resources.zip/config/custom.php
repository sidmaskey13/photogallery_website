<?php
return[
  'max_filesize'=>'500000',
  'max_filesize_video'=>'5000000',
    'media_status'=>[
        '1'=>'Pending',
        '2'=>'Approved',
        '3'=>'Rejected',
        '4'=>'Admin Added',
        '5'=>'Approved Image edited so pending',
        '6'=>'Admin Added for internal branches only',
        '7'=>'Admin Added for internal branches and also in database',
    ],
    'user_type_notification'=>[
        '1'=>'uploader',
        '2'=>'admin',
        '3'=>'super-admin',
    ]
];

