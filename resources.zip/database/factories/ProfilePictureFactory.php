<?php

use Faker\Generator as Faker;

$factory->define(App\ProfilePicture::class, function (Faker $faker) {
    return [
        //
    ];
});
