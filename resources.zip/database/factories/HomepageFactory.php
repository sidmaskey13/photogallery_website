<?php

use Faker\Generator as Faker;

$factory->define(App\Homepage::class, function (Faker $faker) {
    return [
        //
    ];
});
