<?php

use Faker\Generator as Faker;

$factory->define(App\AllImage::class, function (Faker $faker) {
    return [
        //
    ];
});
