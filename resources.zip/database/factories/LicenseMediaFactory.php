<?php

use Faker\Generator as Faker;

$factory->define(App\LicenseMedia::class, function (Faker $faker) {
    return [
        //
    ];
});
