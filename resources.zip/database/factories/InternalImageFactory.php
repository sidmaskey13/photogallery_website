<?php

use Faker\Generator as Faker;

$factory->define(App\InternalImage::class, function (Faker $faker) {
    return [
        //
    ];
});
