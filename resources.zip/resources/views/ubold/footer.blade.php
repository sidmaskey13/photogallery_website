<!-- Footer Start -->
{{--<footer class="footer">--}}
    {{--<div class="container-fluid">--}}
        {{--<div class="row">--}}
            {{--<div class="col-md-6">--}}
                {{--2015 - 2018 &copy; UBold theme by <a href="">Coderthemes</a>--}}
            {{--</div>--}}
            {{--<div class="col-md-6">--}}
                {{--<div class="text-md-right footer-links d-none d-sm-block">--}}

                {{--</div>--}}
            {{--</div>--}}
        {{--</div>--}}
    {{--</div>--}}
{{--</footer>--}}
<!-- end Footer -->

</div>

</div>



<script src="{{asset('ubold/assets/js/vendor.min.js')}}"></script>
<script src="{{asset('js/selectize.js')}}"></script>
<script src="{{asset('ubold/assets/js/app.min.js')}}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.4.0/dropzone.js"></script>
<script src="{{asset('vendor/unisharp/laravel-ckeditor/ckeditor.js')}}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.3/js/bootstrap-select.min.js" charset="utf-8"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.bundle.js" charset="utf-8"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<script src='https://unpkg.com/es6-promise@4.2.4/dist/es6-promise.auto.min.js'></script>
<script src="https://unpkg.com/@mapbox/mapbox-sdk/umd/mapbox-sdk.min.js"></script>
@yield('script')
</body>
</html>