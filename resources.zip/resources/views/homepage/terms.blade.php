@extends('layouts.search-main')

@section('content')
    <h1>Terms and Conditions</h1>
<p>{!! $terms->body !!}</p>
    @endsection